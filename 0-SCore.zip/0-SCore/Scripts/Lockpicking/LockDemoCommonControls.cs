﻿//using UnityEngine;
//using UnityEngine.UI;

//public class LockDemoCommonControls : MonoBehaviour
//{
//    public GameObject canvasUI;
//    public Button[] allTextureButtons;

//    void Update()
//    {
//        if (Input.GetKeyDown(KeyCode.C))
//            canvasUI.SetActive(!canvasUI.activeSelf);

//        if (Input.GetKeyDown(KeyCode.Alpha1))
//            allTextureButtons[0].onClick.Invoke();

//        if (Input.GetKeyDown(KeyCode.Alpha2))
//            allTextureButtons[1].onClick.Invoke();

//        if (Input.GetKeyDown(KeyCode.Alpha3))
//            allTextureButtons[2].onClick.Invoke();

//        if (Input.GetKeyDown(KeyCode.Alpha4))
//            allTextureButtons[3].onClick.Invoke();

//        if (Input.GetKeyDown(KeyCode.Alpha5))
//            allTextureButtons[4].onClick.Invoke();

//        if (Input.GetKeyDown(KeyCode.Alpha6))
//            allTextureButtons[5].onClick.Invoke();

//        if (Input.GetKeyDown(KeyCode.Alpha7))
//            allTextureButtons[6].onClick.Invoke();
//    }
//}

