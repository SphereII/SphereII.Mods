Paid Asset + Scripts: https://assetstore.unity.com/packages/3d/props/tools/lock-picking-key-locks-padlocks-and-ciphers-177270#description

