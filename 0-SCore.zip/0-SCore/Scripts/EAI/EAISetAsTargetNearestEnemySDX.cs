﻿internal class EAISetAsTargetNearestEnemySDX : EAISetNearestEntityAsTarget
{
    // Backwards Compatibility
}