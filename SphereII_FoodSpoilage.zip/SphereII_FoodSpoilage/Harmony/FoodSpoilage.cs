﻿using DMT;
using Harmony;
using System;
using System.Reflection;
using UnityEngine;


public class FoodSpoilage_Mod
{
    public class SphereII_FoodSpoilage : IHarmony
    {
        public void Start()
        {
            Debug.Log(" Loading Patch: " + GetType().ToString());
            var harmony = HarmonyInstance.Create(GetType().ToString());
            harmony.PatchAll(Assembly.GetExecutingAssembly());
        }
    }

    // hook into the ItemStack, which should cover all types of containers. This will run in the update task.
    [HarmonyPatch(typeof(XUiC_ItemStack))]
    [HarmonyPatch("Update")]
    public class SphereII_XUiC_ItemStack_Update
    {
        public static bool Prefix(XUiC_ItemStack __instance)
        {
            // Make sure we are dealing with legitimate stacks.
            if(__instance.ItemStack.IsEmpty())
                return true;

            if(__instance.ItemStack.itemValue == null)
                return true;

            // If the item class has a SpoilageTime, that means it can spoil over time.        
            if(__instance.ItemStack.itemValue.ItemClass != null && __instance.ItemStack.itemValue.ItemClass.Properties.Contains("Spoilable"))
            {
                // Storing the creation time in the Meta field of the ItemValue, which is unused by food.
                if(__instance.ItemStack.itemValue.Meta == 0)
                    __instance.ItemStack.itemValue.Meta = (int)GameManager.Instance.World.GetWorldTime();

                // Grab the current life span of the item. in order to reduce load and slow down spoilage, 
                int currentLifeSpan = (int)GameManager.Instance.World.GetWorldTime() - __instance.ItemStack.itemValue.Meta;

                // By default, have a spoiler hit every 100 ticks, but allow it to be over-rideable in the xml.
                int TickPerLoss = 100;

                // Check if there's a Global Ticks Per Loss Set
                BlockValue ConfigurationBlock = Block.GetBlockValue("ConfigSpoilageBlock");
                if(ConfigurationBlock.Block.Properties.Contains("TicksPerLoss"))
                    TickPerLoss = ConfigurationBlock.Block.Properties.GetInt("TickPerLoss");
 
                // Check if there's a item-specific TickPerLoss
                if(__instance.ItemStack.itemValue.ItemClass.Properties.Contains("TickPerLoss"))
                    TickPerLoss = __instance.ItemStack.itemValue.ItemClass.Properties.GetInt("TickPerLoss");

                //Debug.Log("Tick Per Loss: " + TickPerLoss);
                // if the currentLifeSpan is divisible by TickPerLoss, then increase the use time, which is what we are using for a spoiler counter.
                //Debug.Log(" Current life : " + currentLifeSpan + " TickPerLoss: " + TickPerLoss + " Mod: " + currentLifeSpan % TickPerLoss + " dt: " + _dt);
                if((currentLifeSpan % TickPerLoss) == 0 )
                {
                    // How much durability / spoilage to trigger.
                    float PerUse = 0f;

                    // Check if there's a player involved, which could change the spoilage rate.
                    EntityPlayerLocal player = GameManager.Instance.World.GetPrimaryPlayer();
                    if(player)
                       PerUse = EffectManager.GetValue(PassiveEffects.DegradationPerUse, __instance.ItemStack.itemValue, 1f, player, null, __instance.ItemStack.itemValue.ItemClass.ItemTags, true, true, true, true, 1, true);
                    else
                       PerUse = EffectManager.GetValue(PassiveEffects.DegradationPerUse, __instance.ItemStack.itemValue, 1f, null, null, __instance.ItemStack.itemValue.ItemClass.ItemTags, true, true, true, true, 1, true);

                  
                    // Additional Spoiler flags to increase or decrease the spoil rate
                    switch(__instance.StackLocation)
                    {
                        case XUiC_ItemStack.StackLocationTypes.ToolBelt:  // Tool belt Storage check
                            if(ConfigurationBlock.Block.Properties.Contains("Toolbelt"))
                                PerUse += ConfigurationBlock.Block.Properties.GetFloat("Toolbelt");
                            break;
                        case XUiC_ItemStack.StackLocationTypes.Backpack:        // Back pack storage check
                            if(ConfigurationBlock.Block.Properties.Contains("Backpack"))
                                PerUse += ConfigurationBlock.Block.Properties.GetFloat("Backpack");                  
                            break;
                        case XUiC_ItemStack.StackLocationTypes.LootContainer:    // Loot Container Storage check
                            TileEntityLootContainer container = __instance.xui.lootContainer;
                            if(container != null)
                            {
                                BlockValue Container = GameManager.Instance.World.GetBlock(container.ToWorldPos());
                                if(Container.Block.Properties.Contains("PreserveBonus"))
                                    PerUse -= Container.Block.Properties.GetFloat("PreserveBonus");

                                // If the container does not have a PreserverBonus, read the block configuration for the settings.
                                else if(ConfigurationBlock.Block.Properties.Contains("Container"))
                                    PerUse += ConfigurationBlock.Block.Properties.GetFloat("Container");
                            }
                            break;
                        case XUiC_ItemStack.StackLocationTypes.Creative:  // Ignore Creative Containers
                            return true;                        
                        default:
                            break;
                    }

                    float MinimumSpoilage = 0.1f;
                    if (  ConfigurationBlock.Block.Properties.Contains("MinimumSpoilage"))
                            MinimumSpoilage = ConfigurationBlock.Block.Properties.GetFloat("MinimumSpoilage");

                    // Worse case scenario, no matter what, Spoilage will increment at 0.5.
                    if(PerUse <= MinimumSpoilage)
                        PerUse = 0.1f;

                    __instance.ItemStack.itemValue.UseTimes += PerUse;

                    Debug.Log("ItemStack - " + __instance.ItemStack.itemValue.ItemClass.GetItemName() + " Creation Time: " + __instance.ItemStack.itemValue.Meta + " Spoiled Counter: " + __instance.ItemStack.itemValue.UseTimes + " Time for total Spoilage: " + __instance.ItemStack.itemValue.MaxUseTimes + " Spoiled this Tick check: " + PerUse + " Percent Left: " + __instance.ItemStack.itemValue.PercentUsesLeft);
                    if(__instance.ItemStack.itemValue.PercentUsesLeft <= 0)
                    {
                        Debug.Log("ItemStack: Item Has Spoiled.");

                        // If not defined, set the foodRottingFlesh as a spoiled product. Otherwise use the global / item.
                        String strSpoiledItem = "foodRottingFlesh";
                        if(ConfigurationBlock.Block.Properties.Contains("SpoiledItem"))
                            strSpoiledItem = ConfigurationBlock.Block.Properties.GetString("SpoiledItem");

                        if(__instance.ItemStack.itemValue.ItemClass.Properties.Contains("SpoiledItem"))
                            strSpoiledItem = __instance.ItemStack.itemValue.ItemClass.Properties.GetString("SpoiledItem");

                        // If the item has already spoiled, let it spoil into nothing.
                        if ( strSpoiledItem == __instance.ItemStack.itemValue.ItemClass.GetItemName() )
                            __instance.ItemStack = new ItemStack( ItemValue.None.Clone(), 0);
                        else
                            __instance.ItemStack = new ItemStack(ItemClass.GetItem(strSpoiledItem, true), 1);

                    }
                
                    __instance.ForceRefreshItemStack();
                }

            }

            return true;

        }
    }



}


